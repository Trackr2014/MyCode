package com.chenerzhu.crawler.proxy.pool.common;

/**
 * @author chenerzhu
 * @create 2018-09-08 17:54
 **/
public enum  HttpMethod {
        GET,
        POST,
        PUT,
        PATCH,
        DELETE;
}