package com.chenerzhu.crawler.proxy.pool.common;

/**
 * @author chenerzhu
 * @create 2018-08-31 20:08
 **/
public final class RedisKey {
    public static final String PROXY_IP_KEY="PROXY_IP_KEY";
    public static final String PROXY_IP_RT_KEY="PROXY_IP_RT_KEY";
}