package com.chenerzhu.crawler.proxy.pool.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author chenerzhu
 * @create 2018-08-30 12:38
 **/
@Configuration
public class SpringConfig {

}