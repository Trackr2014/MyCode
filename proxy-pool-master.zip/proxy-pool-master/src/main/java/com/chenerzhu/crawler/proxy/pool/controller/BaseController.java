package com.chenerzhu.crawler.proxy.pool.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * @author chenerzhu
 * @create 2018-08-29 19:52
 **/
public class BaseController {
}